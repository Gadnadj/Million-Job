#include "menu.h"


int main()
{
	printf("\033[1;36m");
	menu();
	return 0;
}






