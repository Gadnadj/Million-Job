#pragma once
#include"candidate.h"
#include"employer.h"

void menu();
char* forgetMyPass(int* num);
char* login(int* num);